package com.example.lab_01_ltdd_04

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.lab_01_ltdd_04.databinding.ActivityMain2Binding

class MainActivity2 : AppCompatActivity() {
    lateinit var acMain2Binding: ActivityMain2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        acMain2Binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(acMain2Binding.root)

        var a = intent.getDoubleExtra("a",0.0)
        var b = intent.getDoubleExtra("b",0.0)
        var c = intent.getDoubleExtra("c",0.0)

        if (a == 0.0) {
            if (b == 0.0) {
                if (c == 0.0) {
                    acMain2Binding.txtKetQua.setText("Phương trình vô số nghiệm")
                    acMain2Binding.txtX1.visibility = View.GONE // View.GONE để ẩn hoàn toàn
                    acMain2Binding.txtX2.visibility = View.GONE
                } else {
                    acMain2Binding.txtKetQua.setText("Phương trình vô nghiệm")
                    acMain2Binding.txtX1.visibility = View.GONE
                    acMain2Binding.txtX2.visibility = View.GONE
                }
            } else {
                acMain2Binding.txtKetQua.setText("Phương trình có một nghiệm duy nhất")
                acMain2Binding.txtX1.setText("x = ${-c/b}")
                acMain2Binding.txtX2.visibility = View.GONE
            }
        } else {
            var delta:Double = (b * b) - (4 * a * c)
            if (delta < 0.0) {
                acMain2Binding.txtKetQua.setText("Phương trình vô nghiệm")
                acMain2Binding.txtX1.visibility = View.GONE
                acMain2Binding.txtX2.visibility = View.GONE
            } else if (delta == 0.0) {
                acMain2Binding.txtKetQua.setText("Phương trình có một nghiệm kép")
                acMain2Binding.txtX1.setText("x = ${-b/(2*a)}")
                acMain2Binding.txtX2.visibility = View.GONE
            } else {
                acMain2Binding.txtKetQua.setText("Phương trình có 2 nghiệm phân biệt:")
                acMain2Binding.txtX1.setText("x1 = " + (-b + Math.sqrt(delta))/(2*a))
                acMain2Binding.txtX2.setText("x2 = " + (-b - Math.sqrt(delta))/(2*a))
            }
        }
    }
}