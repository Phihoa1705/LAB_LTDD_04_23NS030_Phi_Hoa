package com.example.lab_01_ltdd_04

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.lab_01_ltdd_04.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var acMainBinding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        acMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(acMainBinding.root)

        acMainBinding.btnGiaiPT.setOnClickListener {
            var aStr = acMainBinding.edtHeSoA.text.toString()
            var bStr = acMainBinding.edtHeSoB.text.toString()
            var cStr = acMainBinding.edtHeSoC.text.toString()

            if (aStr.isEmpty() || bStr.isEmpty() || cStr.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập đầy đủ hệ số!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener // Thoát khỏi onClickListener ngay lập tức
            }

            val a = aStr.toDoubleOrNull()
            val b = bStr.toDoubleOrNull()
            val c = cStr.toDoubleOrNull()

            if (a == null || b == null || c == null) {
                Toast.makeText(this, "Vui lòng nhập số hợp lệ!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener // Thoát khỏi onClickListener ngay lập tức
            }

            var intent = Intent(this,MainActivity2::class.java)

            intent.putExtra("a",a)
            intent.putExtra("b",b)
            intent.putExtra("c",c)

            startActivity(intent)
        }
    }
}