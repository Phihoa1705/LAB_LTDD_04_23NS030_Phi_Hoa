package com.example.ns030_hoangphihoa

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.ns030_hoangphihoa.databinding.ActivityMath1Binding

class Math1Activity : AppCompatActivity() {
    private lateinit var binding: ActivityMath1Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMath1Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnKiemTra.setOnClickListener {
            val n = binding.edtInput1.text.toString().toIntOrNull()?:0
            var isPrime = true
            for (i in 2 until n) {
                if(n % i == 0) {
                    isPrime = false
                    break
                }
            }

            if (isPrime) {
                binding.txtKetQua.setText("$n là số nguyên tố")
            } else {
                binding.txtKetQua.setText("$n không phải là số nguyên tố")
            }
        }

        //        Lắng nghe sự kiện
        binding.navLeftMenu.setNavigationItemSelectedListener {
            when(it.itemId) {
                R.id.Manager -> {
                    startActivity(Intent(this@Math1Activity, ManagerActivity::class.java))
                    true
                }
                R.id.Math1-> true
                R.id.Math2-> {
                    startActivity(Intent(this@Math1Activity, Math2Activity::class.java))
                    true
                }
            }
            true
        }
    }
}