package com.example.ns030_hoangphihoa.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.ns030_hoangphihoa.model.repository.CanBoRepository

class CanBoViewModelFactory(private val repository: CanBoRepository):ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CanBoViewModel::class.java)) {
            return CanBoViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel Class")
    }
}