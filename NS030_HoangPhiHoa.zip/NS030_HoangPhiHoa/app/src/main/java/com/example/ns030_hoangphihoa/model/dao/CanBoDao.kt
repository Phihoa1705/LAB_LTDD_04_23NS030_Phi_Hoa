package com.example.ns030_hoangphihoa.model.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.ns030_hoangphihoa.model.entity.CanBo

@Dao
interface CanBoDao {
    @Query("SELECT * FROM CanBo")
    fun getAll():LiveData<List<CanBo>>

    @Insert
     suspend fun insert(vararg canBo: CanBo)

    @Delete
    suspend fun delete(canBo: CanBo)

    @Update
    suspend fun update(canBo: CanBo)
}