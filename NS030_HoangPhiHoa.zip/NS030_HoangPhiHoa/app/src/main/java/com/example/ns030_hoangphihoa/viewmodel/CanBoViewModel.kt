package com.example.ns030_hoangphihoa.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ns030_hoangphihoa.model.entity.CanBo
import com.example.ns030_hoangphihoa.model.repository.CanBoRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CanBoViewModel(private val respository:CanBoRepository) :ViewModel() {
    val allCanBo:LiveData<List<CanBo>> = respository.allCanBo

    fun insert(canBo: CanBo) = viewModelScope.launch {
        respository.insert(canBo)
    }

    fun update(canBo: CanBo) = viewModelScope.launch {
        respository.update(canBo)
    }

    fun delete(canBo: CanBo) = viewModelScope.launch {
        respository.delete(canBo)
    }
}