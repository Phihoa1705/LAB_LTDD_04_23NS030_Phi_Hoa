package com.example.ns030_hoangphihoa.model.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class CanBo(
    @PrimaryKey var maCanBo:String,
    @ColumnInfo var tenCanBo:String,
    @ColumnInfo var tuoi:Int,
    @ColumnInfo var queQuan:String
)
