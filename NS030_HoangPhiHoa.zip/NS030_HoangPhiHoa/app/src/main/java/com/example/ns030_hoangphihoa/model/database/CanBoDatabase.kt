package com.example.ns030_hoangphihoa.model.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.ns030_hoangphihoa.model.dao.CanBoDao
import com.example.ns030_hoangphihoa.model.entity.CanBo

@Database(entities = [CanBo::class], version = 1)
abstract class CanBoDatabase :RoomDatabase(){
    abstract fun canBoDao(): CanBoDao

    companion object {
        fun getDatabase(context: Context):CanBoDatabase {
            val database:CanBoDatabase by lazy {
                // Khởi tạo database
                Room.databaseBuilder(context.applicationContext,
                    CanBoDatabase::class.java,"canbo.db").build()
            }
            return database
        }
    }
}