package com.example.ns030_hoangphihoa.view

import com.example.ns030_hoangphihoa.model.entity.CanBo

interface RecyclerInterface {
    fun onEditItem(canbo: CanBo)
    fun onDeleteItem(canbo: CanBo)
    fun onAddItem()
}