package com.example.ns030_hoangphihoa

import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ns030_hoangphihoa.model.database.CanBoDatabase
import com.example.ns030_hoangphihoa.databinding.ActivityManagerBinding
import com.example.ns030_hoangphihoa.model.entity.CanBo
import com.example.ns030_hoangphihoa.model.repository.CanBoRepository
import com.example.ns030_hoangphihoa.view.CustomAdapter
import com.example.ns030_hoangphihoa.view.RecyclerInterface
import com.example.ns030_hoangphihoa.viewmodel.CanBoViewModel
import com.example.ns030_hoangphihoa.viewmodel.CanBoViewModelFactory

class ManagerActivity : AppCompatActivity(),RecyclerInterface {
    private lateinit var binding: ActivityManagerBinding
    private lateinit var viewModel: CanBoViewModel
    private lateinit var adapter: CustomAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityManagerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupViewModel()
        setupRecyclerView()
        setupClickListeners()
        observeData()
    }

    private fun observeData() {
        viewModel.allCanBo.observe(this) {list ->
            adapter.submitList(list)

            if (list.isEmpty()) {
                Toast.makeText(this, "Không tìm thấy cán bộ nào", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupClickListeners() {
        binding.fabAdd.setOnClickListener {
            onAddItem()
        }
    }

    private fun setupRecyclerView() {
        adapter = CustomAdapter(
            list = emptyList(),
            onCanBoClick = this
        )

        binding.RcvManager.apply {
            layoutManager = LinearLayoutManager(this@ManagerActivity)
            adapter = this@ManagerActivity.adapter
        }
    }

    private fun setupViewModel() {
        val canBoDao = CanBoDatabase.getDatabase(this@ManagerActivity).canBoDao()

        val repository = CanBoRepository(canBoDao)
        // Tạo Factory và ViewModel
        val factory = CanBoViewModelFactory(repository)
        viewModel = ViewModelProvider(this,factory).get(CanBoViewModel::class.java)
    }

    override fun onEditItem(canbo: CanBo) {
        val dialogView = LayoutInflater.from(this@ManagerActivity)
            .inflate(R.layout.dialog_add_can_bo,null)
        val edtMaCanBo = dialogView.findViewById<EditText>(R.id.edtMaCanBo)
        val edtTenCanBo = dialogView.findViewById<EditText>(R.id.edtTenCanBo)
        val edtTuoiCanBo = dialogView.findViewById<EditText>(R.id.edtTuoi)
        val edtQueQuanCanBo = dialogView.findViewById<EditText>(R.id.edtQueQuan)

        edtMaCanBo.setText(canbo.maCanBo)
        edtTenCanBo.setText(canbo.tenCanBo)
        edtTuoiCanBo.setText(canbo.tuoi.toString())
        edtQueQuanCanBo.setText(canbo.queQuan)

        AlertDialog.Builder(this)
            .setTitle("Edit Cán Bộ")
            .setView(dialogView)
            .setPositiveButton("Save"){ dialogInterface: DialogInterface, i: Int ->
                val canBoUpdated = canbo.copy(
                    maCanBo = edtMaCanBo.text.toString(),
                    tenCanBo = edtTenCanBo.text.toString(),
                    tuoi = edtTuoiCanBo.text.toString().toIntOrNull()?:canbo.tuoi,
                    queQuan = edtQueQuanCanBo.text.toString()
                )

                viewModel.update(canBoUpdated)
            }
            .setNegativeButton("Cancel",null)
            .show()
    }

    override fun onDeleteItem(canbo: CanBo) {
        if(canbo != null) {
            AlertDialog.Builder(this@ManagerActivity).apply {
                setTitle("Bạn có chắc muốn xóa Cán Bộ ${canbo.maCanBo} ?")
                setPositiveButton("Confrim")
                { dialogInterface: DialogInterface, i: Int ->
                    viewModel.delete(canbo)

                    Toast.makeText(this@ManagerActivity,
                        "Đã xóa cán bộ thành công",
                        Toast.LENGTH_SHORT).show()
                }
                setNegativeButton("Cancel",null)
                show()
            }
        }
    }

    override fun onAddItem() {
        val dialogView = LayoutInflater.from(this@ManagerActivity)
            .inflate(R.layout.dialog_add_can_bo,null)
        val edtMaCanBo = dialogView.findViewById<EditText>(R.id.edtMaCanBo)
        val edtTenCanBo = dialogView.findViewById<EditText>(R.id.edtTenCanBo)
        val edtTuoiCanBo = dialogView.findViewById<EditText>(R.id.edtTuoi)
        val edtQueQuanCanBo = dialogView.findViewById<EditText>(R.id.edtQueQuan)

        AlertDialog.Builder(this@ManagerActivity)
            .setTitle("Add Cán Bộ")
            .setView(dialogView)
            .setPositiveButton("Save"){ dialogInterface: DialogInterface, i: Int ->
                val maCanBo = edtMaCanBo.text.toString()
                val tenCanBo = edtTenCanBo.text.toString()
                val tuoiCanBo = edtTuoiCanBo.text.toString().toIntOrNull()?:0
                val queQuanCanBo = edtQueQuanCanBo.text.toString()

                if (maCanBo.isNotBlank()) {
                    val canbo = CanBo(maCanBo = maCanBo, tenCanBo = tenCanBo,
                                    tuoi = tuoiCanBo, queQuan = queQuanCanBo)

                    viewModel.insert(canbo)
                }
            }
            .setNegativeButton("Cancel",null)
            .show()
    }
}