package com.example.ns030_hoangphihoa.model.repository

import androidx.lifecycle.LiveData
import com.example.ns030_hoangphihoa.model.dao.CanBoDao
import com.example.ns030_hoangphihoa.model.entity.CanBo

class CanBoRepository(private val canBoDao: CanBoDao) {
    val allCanBo:LiveData<List<CanBo>> = canBoDao.getAll()

    suspend fun insert(canBo: CanBo) {
        canBoDao.insert(canBo)
    }

    suspend fun update(canBo: CanBo) {
        canBoDao.update(canBo)
    }

    suspend fun delete(canBo: CanBo) {
        canBoDao.delete(canBo)
    }
}