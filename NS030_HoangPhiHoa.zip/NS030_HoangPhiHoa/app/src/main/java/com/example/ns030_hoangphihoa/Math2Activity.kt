package com.example.ns030_hoangphihoa

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.ns030_hoangphihoa.databinding.ActivityMath2Binding

class Math2Activity : AppCompatActivity() {
    private lateinit var binding: ActivityMath2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMath2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnGiai.setOnClickListener {
            val a:Double = binding.edtInput1.text.toString().toDoubleOrNull()?:0.0
            val b:Double = binding.edtInput2.text.toString().toDoubleOrNull()?:0.0

            if(a == 0.0) {
                if(b == 0.0) {
                    binding.txtKetQua.setText("Phương trình vô số nghiệm")
                } else {
                    binding.txtKetQua.setText("Phương trình vô nghiệm")
                }
            } else {
                binding.txtKetQua.setText("Phương trình có nghiệm x = ${(-b / a)}")
            }
        }

        //        Lắng nghe sự kiện
        binding.navLeftMenu.setNavigationItemSelectedListener {
            when(it.itemId) {
                R.id.Manager -> {
                    startActivity(Intent(this@Math2Activity, ManagerActivity::class.java))
                    true
                }
                R.id.Math1-> {
                    startActivity(Intent(this@Math2Activity, Math1Activity::class.java))
                    true
                }
                R.id.Math2-> {
                    true
                }
            }
            true
        }
    }
}