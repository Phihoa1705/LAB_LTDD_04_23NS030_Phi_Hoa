package com.example.ns030_hoangphihoa.view

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.PopupMenu
import androidx.recyclerview.widget.RecyclerView
import com.example.ns030_hoangphihoa.R
import com.example.ns030_hoangphihoa.databinding.LayoutItemBinding
import com.example.ns030_hoangphihoa.model.entity.CanBo

class CustomAdapter(
    var list: List<CanBo>,
    var onCanBoClick: RecyclerInterface
) : RecyclerView.Adapter<CustomAdapter.ViewHolder>() {

    inner class ViewHolder(private val binding:LayoutItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(canBo: CanBo) {
            binding.apply {
                txtMaCanBo.text = canBo.maCanBo
                txtTenCanBo.text = "Tên: ${canBo.tenCanBo}"
                txtTuoi.text = "Tuổi: ${canBo.tuoi}"
                txtQueQuan.text = "Quê quán ${canBo.queQuan}"

                btnEdit.setOnClickListener{onCanBoClick.onEditItem(canBo)}
                btnDelete.setOnClickListener { onCanBoClick.onDeleteItem(canBo) }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = LayoutItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(list[position])

        // Gán PopupMenu cho item
        holder.itemView.setOnLongClickListener { view ->
            val popupMenu = PopupMenu(view.context,view)
            popupMenu.inflate(R.menu.popup_menu)

            popupMenu.setOnMenuItemClickListener { menuItem ->
                when(menuItem.itemId) {
                    R.id.itemDelete -> {
                        // Gọi phương thức xử lý xóa phần tử
                        onCanBoClick.onDeleteItem(list[position])
                        true
                    }
                    else -> false
                }
            }
            popupMenu.show()
            true
        }
    }


    override fun getItemCount(): Int {
        return list.size
    }

    fun submitList(listNew:List<CanBo>) {
        list = listNew
        notifyDataSetChanged()
    }
}
