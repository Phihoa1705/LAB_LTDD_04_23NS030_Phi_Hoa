package com.example.room_viewmodel_livedata_recylerview_coroutine.model.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true) val id:Int = 0,
    val name: String,
    val age:Int,
    val grade: String,
    @ColumnInfo(name = "created_at") val createdAt:Long = System.currentTimeMillis()
)
