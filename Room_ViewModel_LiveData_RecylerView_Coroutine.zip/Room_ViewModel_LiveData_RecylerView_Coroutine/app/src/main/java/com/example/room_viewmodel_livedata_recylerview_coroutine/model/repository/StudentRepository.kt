package com.example.room_viewmodel_livedata_recylerview_coroutine.model.repository

import androidx.lifecycle.LiveData
import com.example.room_viewmodel_livedata_recylerview_coroutine.model.dao.StudentDAO
import com.example.room_viewmodel_livedata_recylerview_coroutine.model.entity.Student

class StudentRepository(private val studentDAO: StudentDAO) {
    val allStudent:LiveData<List<Student>> = studentDAO.getAllStudents()

    suspend fun insert(student: Student) {
        studentDAO.insert(student)
    }

    suspend fun update(student: Student) {
        studentDAO.update(student)
    }

    suspend fun delete(student: Student) {
        studentDAO.delete(student)
    }
}