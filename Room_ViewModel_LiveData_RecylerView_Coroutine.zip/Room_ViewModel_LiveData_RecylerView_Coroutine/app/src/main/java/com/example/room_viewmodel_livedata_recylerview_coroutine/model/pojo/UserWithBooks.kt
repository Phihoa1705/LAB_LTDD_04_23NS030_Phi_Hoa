package com.example.room_viewmodel_livedata_recylerview_coroutine.model.pojo

import androidx.room.Embedded
import androidx.room.Relation
import com.example.room_viewmodel_livedata_recylerview_coroutine.model.entity.Book
import com.example.room_viewmodel_livedata_recylerview_coroutine.model.entity.User

data class UserWithBooks(
    @Embedded val user: User,
    @Relation(
        parentColumn = "id",
        entityColumn = "user_id",
        entity = Book::class
    )
    val books: List<Book>
)
