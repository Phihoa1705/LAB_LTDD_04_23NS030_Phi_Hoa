package com.example.room_viewmodel_livedata_recylerview_coroutine

import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.room_viewmodel_livedata_recylerview_coroutine.databinding.ActivityMainBinding
import com.example.room_viewmodel_livedata_recylerview_coroutine.model.database.StudentDatabase
import com.example.room_viewmodel_livedata_recylerview_coroutine.model.entity.Student
import com.example.room_viewmodel_livedata_recylerview_coroutine.model.repository.StudentRepository
import com.example.room_viewmodel_livedata_recylerview_coroutine.view.StudentAdapter
import com.example.room_viewmodel_livedata_recylerview_coroutine.viewmodel.StudentViewModel
import com.example.room_viewmodel_livedata_recylerview_coroutine.viewmodel.StudentViewModelFactory

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: StudentViewModel
    private lateinit var adapter: StudentAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setUpViewModel()
        setupRecyclerView()
        setupClickListeners()
        observeData()
    }

    private fun observeData() {
        viewModel.allStudent.observe(this) { students ->
            adapter.submitList(students)

//            Hiển thị thông báo nếu không có dữ liệu
            if (students.isEmpty()) {
                Toast.makeText(this@MainActivity,
                    "No students found",
                    Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupClickListeners() {
        binding.fabAdd.setOnClickListener {
            showAddDialog()
        }
    }

    private fun showAddDialog() {
        val dialogView = LayoutInflater
            .from(this@MainActivity).inflate(R.layout.dialog_add_student,null)

        val editName = dialogView.findViewById<EditText>(R.id.etName)
        val editAge = dialogView.findViewById<EditText>(R.id.etAge)
        val editGrade = dialogView.findViewById<EditText>(R.id.etGrade)

        AlertDialog.Builder(this@MainActivity)
            .setTitle("Add Student")
            .setView(dialogView)
            .setPositiveButton("Save") { dialogInterface: DialogInterface, i: Int ->
                val name = editName.text.toString()
                val age = editAge.text.toString().toIntOrNull()?:0
                val grade = editGrade.text.toString()

                if (name.isNotBlank()) {
                    val  student = Student(name = name, age = age, grade = grade)
                    viewModel.insert(student)
                }
            }
            .setNegativeButton("Cancel",null)
            .show()
    }

    private fun setupRecyclerView() {
        adapter = StudentAdapter(
            students = emptyList(),
            onEditClick = { showEditDialog(it)},
            onDeleteClick = {viewModel.delete(it)}
        )
        binding.rvStudents.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }
    }

    private fun setUpViewModel() {
        val studentDAO = StudentDatabase.getDatabase(this@MainActivity).studentDao()
        val repository = StudentRepository(studentDAO)

//        Tạo Factory và ViewModel
        val factory = StudentViewModelFactory(repository)
        viewModel = ViewModelProvider(this,factory).get(StudentViewModel::class.java)
    }

    private fun showEditDialog(student: Student) {
        val dialogView = LayoutInflater.from(this)
            .inflate(R.layout.dialog_add_student,null)
        val editName = dialogView.findViewById<EditText>(R.id.etName)
        val editAge = dialogView.findViewById<EditText>(R.id.etAge)
        val editGrade = dialogView.findViewById<EditText>(R.id.etGrade)

        editName.setText(student.name)
        editAge.setText(student.age.toString())
        editGrade.setText(student.grade)

        AlertDialog.Builder(this)
            .setTitle("Edit Student")
            .setView(dialogView)
            .setPositiveButton("Save"){ dialogInterface: DialogInterface, i: Int ->
                val updatedStudent = student.copy(
                    name = editName.text.toString(),
                    age = editAge.text.toString().toIntOrNull()?:student.age,
                    grade = editGrade.text.toString()
                )

                viewModel.update(updatedStudent)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}