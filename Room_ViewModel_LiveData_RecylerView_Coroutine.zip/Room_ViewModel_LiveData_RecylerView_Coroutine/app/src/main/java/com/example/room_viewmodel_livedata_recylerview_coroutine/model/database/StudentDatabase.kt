package com.example.room_viewmodel_livedata_recylerview_coroutine.model.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.room_viewmodel_livedata_recylerview_coroutine.model.dao.StudentDAO
import com.example.room_viewmodel_livedata_recylerview_coroutine.model.entity.Student

@Database(entities = [Student::class], version = 1)
abstract class StudentDatabase : RoomDatabase() {
    abstract fun studentDao():StudentDAO

    companion object {
        fun getDatabase(context: Context): StudentDatabase {
            val database: StudentDatabase by lazy {
                // Khởi tạo Database ở đây
                Room.databaseBuilder(
                    context.applicationContext,
                    StudentDatabase::class.java,
                    "myData"
                ).build()
            }
            return database
        }
    }
}