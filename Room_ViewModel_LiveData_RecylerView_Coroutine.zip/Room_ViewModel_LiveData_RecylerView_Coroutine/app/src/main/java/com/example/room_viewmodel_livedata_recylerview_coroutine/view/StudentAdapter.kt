package com.example.room_viewmodel_livedata_recylerview_coroutine.view

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.room_viewmodel_livedata_recylerview_coroutine.databinding.ItemStudentBinding
import com.example.room_viewmodel_livedata_recylerview_coroutine.model.entity.Student

class StudentAdapter(
    var students:List<Student>,
    private val onEditClick: (Student) -> Unit,
    private val onDeleteClick: (Student) -> Unit
) :RecyclerView.Adapter<StudentAdapter.StudentViewHolder>() {

    inner class StudentViewHolder(private val binding: ItemStudentBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(student: Student) {
            binding.apply {
                tvName.text = student.name
                tvAge.text = "Age: ${student.age}"
                tvGrade.text = "Grade: ${student.grade}"
                btnEdit.setOnClickListener { onEditClick(student) }
                btnDelete.setOnClickListener { onDeleteClick(student) }
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StudentViewHolder {
        val binding = ItemStudentBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return StudentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: StudentViewHolder, position: Int) {
        holder.bind(students[position])
    }

    override fun getItemCount(): Int {
        return students.size
    }

    fun submitList(newStudents:List<Student>) {
        students = newStudents
        notifyDataSetChanged()
    }
}