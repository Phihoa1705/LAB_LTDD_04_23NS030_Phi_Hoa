package com.example.room_viewmodel_livedata_recylerview_coroutine.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.room_viewmodel_livedata_recylerview_coroutine.model.entity.Student
import com.example.room_viewmodel_livedata_recylerview_coroutine.model.repository.StudentRepository
import kotlinx.coroutines.launch

class StudentViewModel(private val repository: StudentRepository) :ViewModel() {
    val allStudent:LiveData<List<Student>> = repository.allStudent

    fun insert(student: Student) = viewModelScope.launch {
        repository.insert(student)
    }

    fun update(student: Student) = viewModelScope.launch {
        repository.update(student)
    }

    fun delete(student: Student) = viewModelScope.launch {
        repository.delete(student)
    }
}